<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Models\Customer;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Validator;

class CustomerValidationTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_validates_customer_creation()
    {
        // Create a customer with a unique email
        Customer::factory()->create(['email' => 'existing@example.com']);

        // Attempt to create a new customer with the same email
        $data = [
            'name' => 'John',
            'email' => 'existing@example.com', // Existing email
            'phone' => '1234567890',
            'address' => '123 Main St',
        ];

        // Validate the request data against the validation rules
        $validator = Validator::make($data, [
            'name' => ['required', 'string'],
            'email' => ['required', 'email', 'unique:customers'],
            'phone' => ['nullable', 'string'],
            'address' => ['nullable', 'string'],
        ]);

        // Assert that the validation fails due to unique email constraint
        $this->assertFalse($validator->passes());
        $this->assertArrayHasKey('email', $validator->errors()->toArray());

        // Attempt to create a new customer with valid data
        $data['email'] = 'new@example.com'; // Unique email

        // Validate the request data again
        $validator = Validator::make($data, [
            'name' => ['required', 'string'],
            'email' => ['required', 'email', 'unique:customers'],
            'phone' => ['nullable', 'string'],
            'address' => ['nullable', 'string'],
        ]);

        // Assert that the validation passes
        $this->assertTrue($validator->passes());
    }
}