<!-- resources/views/user/index.blade.php -->

@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>User Dashboard</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Data</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($userData as $data)
                    <tr>
                        <td>{{ $data->id }}</td>
                        <td>{{ $data->data_field }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
