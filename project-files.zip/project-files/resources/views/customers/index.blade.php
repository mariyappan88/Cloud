<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Customers List') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                <p style="text-align: right;"><a href="{{ route('customer.create') }}" style="color:blue" class="btn btn-primary mb-3">Create New Customer</a></p>
                
                @if ($customers->isEmpty())
                    <p>No customers found.</p>
                    
                @else
                <form action="{{ route('customer.index') }}" method="GET" class="mb-6">
                    <input type="text" name="search" value="{{ request('search') }}" placeholder="Search..." class="border-gray-300 rounded-lg shadow-sm">
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Search</button>
                </form>
                <table class="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="px-4 py-2">ID</th>
                            <th class="px-4 py-2">Name</th>
                            <th class="px-4 py-2">Email</th>
                            <th class="px-4 py-2">Phone</th>
                            <th class="px-4 py-2">Address</th>
                            <th class="px-4 py-2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($customers as $customer)
                            <tr class="hover:bg-gray-100">
                                <td class="border px-4 py-2">{{ $customer->id }}</td>
                                <td class="border px-4 py-2">{{ $customer->name }}</td>
                                <td class="border px-4 py-2">{{ $customer->email }}</td>
                                <td class="border px-4 py-2">{{ $customer->phone }}</td>
                                <td class="border px-4 py-2">{{ $customer->address }}</td>
                                <td class="border px-4 py-2">
                                    <a href="{{ route('customer.edit', $customer->id) }}" class="text-green-500 hover:text-green-700 px-2">Edit</a>
                                    <form action="{{ route('customer.destroy', $customer->id) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-500 hover:text-red-700 px-2" onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

