<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Leads List') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                
                <form action="{{ route('lead.index') }}" method="GET">
                <div class="form-group">
                    <label for="state">Filter by State:</label>
                    <select name="state" id="state" class="form-control" onchange="this.form.submit()">
                        <option value="">All States</option>
                        <option value="New" {{ request('state') == 'New' ? 'selected' : '' }}>New</option>
                        <option value="Contacted" {{ request('state') == 'Contacted' ? 'selected' : '' }}>Contacted</option>
                        <option value="Qualified" {{ request('state') == 'Qualified' ? 'selected' : '' }}>Qualified</option>
                        <option value="Lost" {{ request('state') == 'Lost' ? 'selected' : '' }}>Lost</option>
                    </select>
                </div>
                    
                </form>

                <p style="text-align: right;"><a href="{{ route('leads.create') }}" style="color:blue" class="btn btn-primary mb-3">Create New lead</a></p>
                
                @if ($leads->isEmpty())
                    <p>No leads found.</p>
                    
                @else
                 
                <table class="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="px-4 py-2">ID</th>
                            <th class="px-4 py-2">Customer</th>
                            <th class="px-4 py-2">Status</th>
                            <th class="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach ($leads as $lead)
                            <tr>
                                <td class="border px-4 py-2">{{ $lead->id }}</td>
                                <td class="border px-4 py-2">{{ $lead->customer->name }}</td>
                                <td class="border px-4 py-2">{{ $lead->state }}</td>
                                <td class="border px-4 py-2">
                                    <a href="{{ route('leads.edit', $lead->id) }}" class="text-indigo-600 hover:text-indigo-900">Edit</a>
                                    <form action="{{ route('leads.destroy', $lead->id) }}" method="POST" style="display:inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

