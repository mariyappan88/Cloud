<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Leads List') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg" style="padding:10px">
        <h1 class="text-2xl font-bold mb-6">Edit Lead</h1>

        <form action="{{ route('leads.update', $lead->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="mb-4">
                <label for="customer_id" class="block text-gray-700">Customer</label>
                <select name="customer_id" id="customer_id" class="form-select mt-1 block w-full">
                    @foreach($customers as $customer)
                        <option value="{{ $customer->id }}" {{ $customer->id == $lead->customer_id ? 'selected' : '' }}>{{ $customer->name }}</option>
                    @endforeach
                </select>
            </div>

            <div class="mb-4">
                <label for="state" class="block text-gray-700">State</label>
                <select name="state" id="state" class="form-select mt-1 block w-full">
                    <option value="New" {{ $lead->state == 'New' ? 'selected' : '' }}>New</option>
                    <option value="Contacted" {{ $lead->state == 'Contacted' ? 'selected' : '' }}>Contacted</option>
                    <option value="Qualified" {{ $lead->state == 'Qualified' ? 'selected' : '' }}>Qualified</option>
                    <option value="Lost" {{ $lead->state == 'Lost' ? 'selected' : '' }}>Lost</option>
                </select>
            </div>

            <!-- Add other fields as needed -->

            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Update</button>
        </form>

        </div>
        </div>
        </div>
    </div>
</x-app-layout>
