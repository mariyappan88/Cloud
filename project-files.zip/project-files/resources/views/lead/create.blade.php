<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Leads List') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg" style="padding:10px">
            <h1 class="text-2xl font-bold mb-6">Create Lead</h1>

            <form action="{{ route('leads.store') }}" method="POST">
            @csrf
            <div class="mb-4">
                <label for="customer_id" class="block text-gray-700">Customer</label>
                <select name="customer_id" id="customer_id" class="form-select mt-1 block w-full">
                    @foreach($customers as $customer)
                        <option value="{{ $customer->id }}">{{ $customer->name }}</option>
                    @endforeach
                </select>
            </div>

            <div class="mb-4">
                <label for="state" class="block text-gray-700">State</label>
                <select name="state" id="state" class="form-select mt-1 block w-full">
                    <option value="New">New</option>
                    <option value="Contacted">Contacted</option>
                    <option value="Qualified">Qualified</option>
                    <option value="Lost">Lost</option>
                </select>
            </div>

            <!-- Add other fields as needed -->

            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Create</button>
        </form>
        </div>
        </div>
        </div>
    </div>
</x-app-layout>

