<!-- resources/views/admin/index.blade.php -->

@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Admin Dashboard</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Data</th>
                    <th>User ID</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($allData as $data)
                    <tr>
                        <td>{{ $data->id }}</td>
                        <td>{{ $data->data_field }}</td>
                        <td>{{ $data->user_id }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
