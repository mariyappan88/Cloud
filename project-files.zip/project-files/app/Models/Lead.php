<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Customer;

class Lead extends Model
{
    protected $fillable = ['state']; // other fillable fields as needed

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

}
