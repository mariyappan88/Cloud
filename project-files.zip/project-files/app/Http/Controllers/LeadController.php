<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Lead;
use App\Models\Customer;
use App\Notifications\NewUserNotification;

class LeadController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $leads = Lead::when($request->state, function ($query, $state) {
            return $query->where('state', $state);
        })->get();
    
        return view('lead.index', [
            'leads' => $leads,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Retrieve all customers for dropdown options
        $customers = Customer::all();

        // Or you can retrieve specific data if needed
        // $customers = Customer::pluck('name', 'id');

        // Pass the $customers variable to the create view
        return view('lead.create', compact('customers'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        
        $validatedData = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'state' => 'required|in:New,Contacted,Qualified,Lost',
            // Add validation rules for other fields as needed
        ]);
        
        // Create a new lead record
        $lead = new Lead();
        $lead->customer_id = $validatedData['customer_id'];
        $lead->state = $validatedData['state'];
        
        // Add other fields as needed and assign them similarly
        // $customerName = $lead->customer->name;
        $lead->save();
        // if($lead->save()){
        //     $lead->notify(new NewUserNotification($customerName));

        //     return "Notification sent successfully!";
        // }

        return redirect()->route('lead.index')
                         ->with('success', 'Lead created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Lead $lead)
    {
        return view('lead.show', compact('lead'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request, $id)
    {
        // Retrieve the lead you want to edit
        $lead = Lead::findOrFail($id);

        // Retrieve the specific customer associated with the lead
        $customer = Customer::findOrFail($lead->customer_id);

        // Assuming you also need to fetch all customers for dropdown options
        $customers = Customer::all();

        return view('lead.edit', compact('lead', 'customer', 'customers'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Lead $lead)
    {
        $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'state' => 'required|in:New,Contacted,Qualified,Lost',
        ]);

        $lead->update($request->all());
        return redirect()->route('lead.index')
                         ->with('success', 'Lead updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Lead $lead)
    {
        $lead->delete();
        return redirect()->route('lead.index')
                         ->with('success', 'Lead deleted successfully.');
    }
}
