<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DataModel;

class AdminController extends Controller
{
    public function index()
    {
        $allData = DataModel::all(); // Admin can access all data
        return view('admin.index', compact('allData'));
    }
}
