<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\LeadController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Admin routes
Route::middleware(['auth', 'role:Admin'])->group(function () {
    Route::get('/admin', [AdminController::class, 'index'])->name('admin.index');
    // other admin routes
});

// Regular user routes
Route::middleware(['auth', 'role:Regular'])->group(function () {
    Route::get('/user', [UserController::class, 'index'])->name('user.index');
    // other user routes
});

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    //Customer Management
    Route::resource('/customers', CustomerController::class)->names
    ([  'index'=>'customer.index',
        'create'=>'customer.create',
        'edit'=>'customer.edit', 
        'destroy'=>'customer.destroy'
    ]);
    // Lead  Management
    Route::resource('/leads', LeadController::class)->names
    ([
        'index'=>'lead.index',
        'create'=>'lead.create',
        'edit'=>'lead.edit', 
        'destroy'=>'lead.destroy'
    ]);
});




require __DIR__.'/auth.php';
