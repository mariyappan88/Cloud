<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Lead;
use App\Models\Customer;

class LeadsSeeder extends Seeder
{
    public function run()
    {
        // Ensure you have some customers to link leads to
        if (Customer::count() == 0) {
            // You might want to run CustomerSeeder first or create some dummy customers here
            Customer::factory()->count(10)->create();
        }

        $customers = Customer::all();

        // Create sample leads
        foreach ($customers as $customer) {
            Lead::create([
                'customer_id' => $customer->id,
                'state' => array_rand(['New', 'Contacted', 'Qualified', 'Lost']),
                // Add other fields as needed
            ]);
        }
    }

    // Helper function to get a random state
    private function getRandomState()
    {
        $states = ['New', 'Contacted', 'Qualified', 'Lost'];
        return $states[array_rand($states)];
    }
}
