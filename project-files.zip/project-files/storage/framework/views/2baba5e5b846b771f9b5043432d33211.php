<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Leads List')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                
                <form action="<?php echo e(route('lead.index')); ?>" method="GET">
                <div class="form-group">
                    <label for="state">Filter by State:</label>
                    <select name="state" id="state" class="form-control" onchange="this.form.submit()">
                        <option value="">All States</option>
                        <option value="New" <?php echo e(request('state') == 'New' ? 'selected' : ''); ?>>New</option>
                        <option value="Contacted" <?php echo e(request('state') == 'Contacted' ? 'selected' : ''); ?>>Contacted</option>
                        <option value="Qualified" <?php echo e(request('state') == 'Qualified' ? 'selected' : ''); ?>>Qualified</option>
                        <option value="Lost" <?php echo e(request('state') == 'Lost' ? 'selected' : ''); ?>>Lost</option>
                    </select>
                </div>
                    
                </form>

                <p style="text-align: right;"><a href="<?php echo e(route('leads.create')); ?>" style="color:blue" class="btn btn-primary mb-3">Create New lead</a></p>
                
                <?php if($leads->isEmpty()): ?>
                    <p>No leads found.</p>
                    
                <?php else: ?>
                 
                <table class="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="px-4 py-2">ID</th>
                            <th class="px-4 py-2">Customer</th>
                            <th class="px-4 py-2">Status</th>
                            <th class="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="border px-4 py-2"><?php echo e($lead->id); ?></td>
                                <td class="border px-4 py-2"><?php echo e($lead->customer->name); ?></td>
                                <td class="border px-4 py-2"><?php echo e($lead->state); ?></td>
                                <td class="border px-4 py-2">
                                    <a href="<?php echo e(route('leads.edit', $lead->id)); ?>" class="text-indigo-600 hover:text-indigo-900">Edit</a>
                                    <form action="<?php echo e(route('leads.destroy', $lead->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\cloud\resources\views/lead/index.blade.php ENDPATH**/ ?>